package service;

import model.*;

public class TransportService {

    public static Transport createTransport(String type, int vehicleNumber, Route route) {

        if (type.equalsIgnoreCase("Student")) {
            return new StudentBus(vehicleNumber, route);
        } else {
            return new StaffCar(vehicleNumber, route);
        }
    }
}
