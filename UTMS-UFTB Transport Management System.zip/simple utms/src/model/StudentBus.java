package model;

public class StudentBus extends Transport {

    public StudentBus(int vehicleNumber, Route route) {
        super(vehicleNumber, route);
    }

    @Override
    public String getType() {
        return "Student Bus";
    }
}
