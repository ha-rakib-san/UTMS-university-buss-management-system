package model;

public abstract class Transport {
    protected int vehicleNumber;
    protected Route route;

    public Transport(int vehicleNumber, Route route) {
        this.vehicleNumber = vehicleNumber;
        this.route = route;
    }

    public int getVehicleNumber() {
        return vehicleNumber;
    }

    public Route getRoute() {
        return route;
    }

    public abstract String getType();
}
