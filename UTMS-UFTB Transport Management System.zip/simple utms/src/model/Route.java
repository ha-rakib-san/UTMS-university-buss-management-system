package model;

public class Route {
    private String pickup;
    private String drop;

    public Route(String pickup, String drop) {
        this.pickup = pickup;
        this.drop = drop;
    }

    public String getPickup() {
        return pickup;
    }

    public String getDrop() {
        return drop;
    }

    // This method fixes your error
    public String getRoute() {
        return pickup + " -> " + drop;
    }
}
