package model;

public class StaffCar extends Transport {

    public StaffCar(int vehicleNumber, Route route) {
        super(vehicleNumber, route);
    }

    @Override
    public String getType() {
        return "Teacher Car";
    }
}
