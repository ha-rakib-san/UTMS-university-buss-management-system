package model;

public class Assignment {

    private Person person;
    private Transport transport;

    public Assignment(Person person, Transport transport) {
        this.person = person;
        this.transport = transport;
    }

    public String toFileString() {
        return person.getInfo() + ","
                + transport.getType() + ","
                + transport.getVehicleNumber() + ","
                + transport.getRoute().getRoute();
    }
}
