package ui;

import javax.swing.*;
import service.RecordService;

public class ViewRecordsUI extends JFrame {

    public ViewRecordsUI() {
        setTitle("UTMS-UFTB Records");
        setSize(500, 400);

        JTextArea area = new JTextArea();
        area.setEditable(false);
        area.setText(RecordService.loadRecords());

        add(new JScrollPane(area));
        setVisible(true);
    }
}