package ui;

import model.*;
import service.TransportService;
import service.RecordService;

import javax.swing.*;
import java.awt.*;

public class AssignTransportUI extends JFrame {

    JComboBox<String> typeBox, vehicleBox;
    JTextField nameField, idField, deptField, pickupField, dropField;
    JButton saveBtn;

    public AssignTransportUI() {
        setTitle("UTMS-UFTB Assign Transport");
        setSize(450, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        setLayout(new GridLayout(9, 2, 10, 10));

        // Row 1
        add(new JLabel("Type:"));
        typeBox = new JComboBox<>(new String[]{"Student", "Teacher"});
        add(typeBox);

        // Row 2
        add(new JLabel("Name:"));
        nameField = new JTextField();
        add(nameField);

        // Row 3
        add(new JLabel("ID:"));
        idField = new JTextField();
        add(idField);

        // Row 4
        add(new JLabel("Department:"));
        deptField = new JTextField();
        add(deptField);

        // Row 5
        add(new JLabel("Pickup:"));
        pickupField = new JTextField();
        add(pickupField);

        // Row 6
        add(new JLabel("Drop:"));
        dropField = new JTextField();
        add(dropField);

        // Row 7
        add(new JLabel("Vehicle Number:"));
        vehicleBox = new JComboBox<>(new String[]{"1", "2"});
        add(vehicleBox);

        // Empty space
        add(new JLabel(""));
        saveBtn = new JButton("Save");
        add(saveBtn);

        saveBtn.addActionListener(e -> saveRecord());

        setVisible(true);
    }

    private void saveRecord() {
        try {
            String type = typeBox.getSelectedItem().toString();
            String name = nameField.getText();
            String id = idField.getText();
            String dept = deptField.getText();
            String pickup = pickupField.getText();
            String drop = dropField.getText();
            int vehicleNumber = Integer.parseInt(vehicleBox.getSelectedItem().toString());

            if (name.isEmpty() || id.isEmpty() || dept.isEmpty() || pickup.isEmpty() || drop.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields are required!");
                return;
            }

            Person person;
            if (type.equals("Student")) {
                person = new Student(name, id, dept);
            } else {
                person = new Staff(name, id, dept);
            }

            Route route = new Route(pickup, drop);
            Transport transport = TransportService.createTransport(type, vehicleNumber, route);

            Assignment assignment = new Assignment(person, transport);
            RecordService.saveRecord(assignment);

            JOptionPane.showMessageDialog(this, "Transport Assigned Successfully!");

            dispose();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }
}
