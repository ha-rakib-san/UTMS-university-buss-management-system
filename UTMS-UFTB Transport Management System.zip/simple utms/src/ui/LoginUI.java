package ui;

import javax.swing.*;
import java.awt.*;

public class LoginUI extends JFrame {

    public LoginUI() {
        setTitle("UTMS-UFTB Login");
        setSize(300, 200);
        setLayout(new GridLayout(3, 2));

        JTextField user = new JTextField();
        JPasswordField pass = new JPasswordField();
        JButton login = new JButton("Login");

        add(new JLabel("Username"));
        add(user);
        add(new JLabel("Password"));
        add(pass);
        add(login);

        login.addActionListener(e -> {
            if (user.getText().equals("admin") && new String(pass.getPassword()).equals("1234")) {
                new DashboardUI();
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid login!");
            }
        });

        setVisible(true);
    }
}
