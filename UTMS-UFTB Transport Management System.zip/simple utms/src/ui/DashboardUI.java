package ui;

import javax.swing.*;
import java.awt.*;

public class DashboardUI extends JFrame {

    public DashboardUI() {
        setTitle("UTMS-UFTB Dashboard");
        setSize(300, 200);
        setLayout(new GridLayout(2, 1));

        JButton assign = new JButton("Assign Transport");
        JButton view = new JButton("View Records");

        add(assign);
        add(view);

        assign.addActionListener(e -> new AssignTransportUI());
        view.addActionListener(e -> new ViewRecordsUI());

        setVisible(true);
    }
}
