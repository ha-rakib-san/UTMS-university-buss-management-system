package ui;

import java.awt.*;
import javax.swing.*;

public class LoginUI extends JFrame {

    public LoginUI() {
        setTitle("UFTB UTMS LOGIN SYSTEM");
        
        // Simply large interface size
        setSize(550, 500); 
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLayout(new GridBagLayout());
        getContentPane().setBackground(new Color(245, 245, 245));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15);
        
        // --- Fonts ---
        Font headingFont = new Font("SansSerif", Font.BOLD, 24);
        Font largeLabelFont = new Font("SansSerif", Font.BOLD, 18);
        Font fieldFont = new Font("SansSerif", Font.PLAIN, 16);
        Font footerFont = new Font("SansSerif", Font.PLAIN, 11);

        // --- 1. Main Heading ---
        JLabel headingLabel = new JLabel("UFTB Transport Management System", SwingConstants.CENTER);
        headingLabel.setFont(headingFont);
        headingLabel.setForeground(new Color(0, 51, 102)); 
        
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2; 
        gbc.insets = new Insets(20, 10, 40, 10); 
        gbc.anchor = GridBagConstraints.CENTER;
        add(headingLabel, gbc);

        // --- Reset for Rows ---
        gbc.gridwidth = 1;
        gbc.insets = new Insets(10, 15, 10, 15);

        // --- UI Components ---
        JTextField user = new JTextField(15);
        user.setFont(fieldFont);
        
        JPasswordField pass = new JPasswordField(15);
        pass.setFont(fieldFont);
        
        JButton login = new JButton("Login");
        login.setFont(new Font("SansSerif", Font.BOLD, 16));
        login.setPreferredSize(new Dimension(120, 40)); 

        JLabel userLabel = new JLabel("Username:");
        userLabel.setFont(largeLabelFont);
        
        JLabel passLabel = new JLabel("Password:");
        passLabel.setFont(largeLabelFont);

        // --- Row 2: Username ---
        gbc.gridx = 0; 
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.LINE_END;
        add(userLabel, gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.LINE_START;
        add(user, gbc);

        // --- Row 3: Password ---
        gbc.gridx = 0; 
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.LINE_END;
        add(passLabel, gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.LINE_START;
        add(pass, gbc);

        // --- Row 4: Button ---
        gbc.gridx = 0; 
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER; 
        gbc.insets = new Insets(30, 10, 10, 10);
        add(login, gbc);

        // --- Row 5: Footer Credits (FIXED ALIGNMENT) ---
        // Added text-align: right to ensure the lines align to the edge
        String footerText = "<html><div style='text-align: right;'>UTMS Created by:<br>" +
                           "Grantha, Jim, Rakib, Sajib, Arafat, Nafiz<br>" +
                           "Department Of - Data Science And Engineering<br>" +
                           "University Of Frontier Technology, Bangladesh</div></html>";
        JLabel footerLabel = new JLabel(footerText);
        footerLabel.setFont(footerFont);
        footerLabel.setForeground(new Color(80, 80, 80)); 
        
        gbc.gridy = 4;
        gbc.gridx = 0;
        gbc.gridwidth = 2; // Span across the bottom
        gbc.weighty = 1.0; 
        gbc.anchor = GridBagConstraints.SOUTHEAST; // Moves to Bottom Right corner
        gbc.insets = new Insets(20, 10, 10, 20); // Added 20 right padding
        add(footerLabel, gbc);

        // --- Logic ---
        login.addActionListener(e -> {
            if (user.getText().equals("admin") && new String(pass.getPassword()).equals("1234")) {
                new DashboardUI();
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid login!");
            }
        });

        setVisible(true);
    }
}